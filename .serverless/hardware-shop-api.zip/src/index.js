const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const serverless = require("serverless-http");

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// ------------------------------------------------------------------
// FIXED CORS CONFIGURATION - Handle Preflight Properly
// ------------------------------------------------------------------
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "https://fsinterprises.vercel.app,http://localhost:5173")
  .split(",")
  .map(o => o.trim());

console.log("🛡️ Allowed CORS Origins:", allowedOrigins);

// Request logger to see both OPTIONS and actual requests
app.use((req, res, next) => {
  console.log('🌐 Incoming Request:', {
    method: req.method,
    url: req.originalUrl,
    origin: req.headers.origin || 'no-origin',
    contentType: req.headers['content-type'],
    timestamp: new Date().toISOString()
  });
  next();
});

// CORS middleware - Handle preflight and actual requests
app.use((req, res, next) => {
  const origin = req.headers.origin;

  // Check if origin is allowed
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    
    // Handle preflight OPTIONS request
    if (req.method === "OPTIONS") {
      res.setHeader(
        "Access-Control-Allow-Headers",
        "Content-Type, Authorization, Origin, X-Requested-With, Accept"
      );
      res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, HEAD, PUT, PATCH, POST, DELETE, OPTIONS"
      );
      res.setHeader("Access-Control-Max-Age", "86400");
      console.log('🛬 Preflight OPTIONS request handled for:', origin);
      return res.status(200).send(); // End the response for preflight
    }
  } else if (origin) {
    console.log('❌ CORS blocked origin:', origin);
  }

  next();
});

// ------------------------------------------------------------------
// MIDDLEWARE
// ------------------------------------------------------------------
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ------------------------------------------------------------------
// ROUTES
// ------------------------------------------------------------------
const authRoutes = require("./routes/auth.routes.js");
const userRoutes = require("./routes/user.routes.js");
const productRoutes = require("./routes/product.routes.js");
const categoryRoutes = require("./routes/category.routes.js");
const orderRoutes = require("./routes/order.routes");

// Use routes with /api prefix
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/products", productRoutes);
app.use("/api/categories", categoryRoutes);
app.use("/api/orders", orderRoutes);

// ------------------------------------------------------------------
// HEALTH CHECK & ROOT ENDPOINT
// ------------------------------------------------------------------
app.get("/", (req, res) => {
  res.json({ 
    message: "Hardware Shop API is running",
    environment: process.env.NODE_ENV || "development",
    timestamp: new Date().toISOString(),
    cors: {
      allowedOrigins: allowedOrigins,
      yourOrigin: req.headers.origin || 'none'
    }
  });
});

app.get("/welcome", (req, res) => {
  res.json({ message: "Welcome to Hardware Shop API" });
});

app.get("/health", (req, res) => {
  res.status(200).json({ 
    status: "OK", 
    database: mongoose.connection.readyState === 1 ? "connected" : "disconnected",
    timestamp: new Date().toISOString(),
    origin: req.headers.origin || 'none'
  });
});

// Test endpoint to verify CORS is working
app.post("/api/test-cors", (req, res) => {
  res.json({ 
    success: true, 
    message: "CORS is working!",
    origin: req.headers.origin,
    timestamp: new Date().toISOString()
  });
});

// ------------------------------------------------------------------
// PROXY PATH HANDLING FOR SERVERLESS
// ------------------------------------------------------------------
app.use((req, res, next) => {
  const originalUrl = req.originalUrl;
  const stage = process.env.SERVERLESS_STAGE || 'dev';
  
  if (originalUrl.startsWith(`/${stage}/`)) {
    req.url = originalUrl.replace(`/${stage}`, '');
    console.log(`🔄 Rewriting URL: ${originalUrl} -> ${req.url}`);
  }
  next();
});

// ------------------------------------------------------------------
// ERROR HANDLING MIDDLEWARE
// ------------------------------------------------------------------
app.use((err, req, res, next) => {
  console.error("💥 Error:", err.stack);
  
  // Handle CORS errors
  if (err.message.includes('CORS policy')) {
    return res.status(403).json({
      success: false,
      message: "CORS policy violation: Origin not allowed",
      allowedOrigins: allowedOrigins,
      yourOrigin: req.headers.origin
    });
  }
  
  const statusCode = err.status || 500;
  res.status(statusCode).json({
    success: false,
    message: statusCode === 500 && process.env.NODE_ENV === "production" 
      ? "Internal Server Error" 
      : err.message,
  });
});

// 404 Handler - MUST be after all routes
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
    availableEndpoints: [
      "/", "/health", "/welcome", 
      "/api/auth/*", "/api/users/*", 
      "/api/products/*", "/api/test-cors"
    ]
  });
});

// ------------------------------------------------------------------
// DATABASE CONNECTION & SERVERLESS CONFIG
// ------------------------------------------------------------------
let isDatabaseConnected = false;

const connectDatabase = async () => {
  try {
    if (!isDatabaseConnected) {
      await mongoose.connect(
        process.env.MONGODB_URI || "mongodb://localhost:27017/hardware-shop",
        {
          useNewUrlParser: true,
          useUnifiedTopology: true,
        }
      );
      isDatabaseConnected = true;
      console.log("✅ Connected to MongoDB");
    }
  } catch (error) {
    console.error("❌ MongoDB connection error:", error.message);
    isDatabaseConnected = false;
  }
};

// For local development
if (process.env.IS_OFFLINE || process.env.NODE_ENV === 'development') {
  connectDatabase().then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 Server running locally on port ${PORT}`);
      console.log(`📝 Environment: ${process.env.NODE_ENV || "development"}`);
      console.log(`🛡️ CORS Allowed Origins: ${allowedOrigins.join(', ')}`);
      console.log(`🌐 Health check: http://localhost:${PORT}/health`);
      console.log(`🧪 Test CORS: http://localhost:${PORT}/api/test-cors`);
    });
  });
} else {
  // For Lambda - connect on cold start
  connectDatabase();
}

// Export the serverless handler
module.exports.handler = serverless(app, {
  binary: ['image/*', 'application/pdf']
});

// Export app for testing
module.exports.app = app;