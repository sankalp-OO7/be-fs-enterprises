const express = require("express");
const router = express.Router();
const authController = require("../controllers/auth.controller.js");

router.post("/register", authController.register);
router.post("/login", authController.login);
router.post("/register-admin", authController.registerAdmin);
router.post('/debug-login', async (req, res) => {
  try {
    console.log('🔍 DEBUG Login Request:', {
      body: req.body,
      headers: req.headers,
      env: process.env.NODE_ENV,
      hasMongoURI: !!process.env.MONGODB_URI,
      hasJWTSecret: !!process.env.JWT_SECRET
    });

    // Simulate a successful login
    res.json({
      success: true,
      message: 'Debug login successful',
      environment: process.env.NODE_ENV,
      token: 'debug-token-123',
      user: { id: 'debug-user', email: req.body.email }
    });
  } catch (error) {
    console.error('Debug login error:', error);
    res.status(500).json({ error: error.message });
  }
});
module.exports = router;
